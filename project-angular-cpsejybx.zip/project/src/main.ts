import { Component } from '@angular/core';
import { bootstrapApplication } from '@angular/platform-browser';
import { provideRouter, RouterOutlet } from '@angular/router';
import { provideAnimations } from '@angular/platform-browser/animations';
import { RegionListComponent } from './app/components/region-list/region-list.component';
import { RegionDetailComponent } from './app/components/region-detail/region-detail.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet],
  template: `
    <router-outlet></router-outlet>
  `
})
export class App {}

bootstrapApplication(App, {
  providers: [
    provideRouter([
      { path: '', component: RegionListComponent },
      { path: 'region/:id', component: RegionDetailComponent }
    ]),
    provideAnimations()
  ]
});