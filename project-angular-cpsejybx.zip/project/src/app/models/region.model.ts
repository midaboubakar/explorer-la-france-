export interface Region {
  id: number;
  nom: string;
  description: string;
  image: string;
}

export interface Activite {
  id: number;
  regionId: number;
  nom: string;
  description: string;
  image: string;
  lieu: string;
}
