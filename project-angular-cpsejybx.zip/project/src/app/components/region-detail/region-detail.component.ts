import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { REGIONS, ACTIVITES } from '../../data/regions';
import { Region, Activite } from '../../models/region.model';

@Component({
  selector: 'app-region-detail',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <div class="container" *ngIf="region">
      <div class="region-header">
        <h1>{{ region.nom }}</h1>
        <div class="region-image-container">
          <img [src]="region.image" [alt]="region.nom" class="region-image">
          <div class="region-overlay">
            <p class="region-description">{{ region.description }}</p>
          </div>
        </div>
      </div>
      
      <section class="activities-section">
        <h2>Activités à découvrir</h2>
        <div class="activites-grid">
          <div *ngFor="let activite of activites" class="activite-card" [@fadeInOut]>
            <div class="activite-image-container">
              <img [src]="activite.image" [alt]="activite.nom">
              <div class="activite-badge">{{ activite.lieu }}</div>
            </div>
            <div class="activite-content">
              <h3>{{ activite.nom }}</h3>
              <p>{{ activite.description }}</p>
              <button class="btn-reserve">Réserver maintenant</button>
            </div>
          </div>
        </div>
      </section>

      <div class="back-to-home">
        <a [routerLink]="['/']" class="btn-back">← Retour à l'accueil</a>
      </div>
    </div>
  `,
  styles: [`
    .container {
      max-width: 1400px;
      margin: 0 auto;
      padding: 20px;
    }

    .region-header {
      margin-bottom: 50px;
    }

    .region-image-container {
      position: relative;
      border-radius: 15px;
      overflow: hidden;
      margin-top: 20px;
    }

    .region-image {
      width: 100%;
      height: 500px;
      object-fit: cover;
    }

    .region-overlay {
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
      background: linear-gradient(transparent, rgba(0, 0, 0, 0.8));
      padding: 30px;
      color: white;
    }

    .region-description {
      font-size: 1.2em;
      line-height: 1.6;
      max-width: 800px;
    }

    .activities-section {
      margin: 50px 0;
    }

    .activities-section h2 {
      text-align: center;
      margin-bottom: 30px;
    }

    .activites-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 30px;
    }

    .activite-card {
      background: white;
      border-radius: 15px;
      overflow: hidden;
      box-shadow: var(--card-shadow);
      transition: transform var(--transition-speed);
    }

    .activite-card:hover {
      transform: translateY(-5px);
    }

    .activite-image-container {
      position: relative;
      height: 200px;
    }

    .activite-image-container img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    .activite-badge {
      position: absolute;
      top: 15px;
      right: 15px;
      background: var(--secondary-color);
      color: white;
      padding: 8px 15px;
      border-radius: 20px;
      font-size: 0.9em;
      font-weight: bold;
    }

    .activite-content {
      padding: 20px;
    }

    .activite-content h3 {
      font-size: 1.4em;
      color: var(--primary-color);
      margin-bottom: 10px;
    }

    .activite-content p {
      color: #666;
      margin-bottom: 20px;
    }

    .btn-reserve {
      background: var(--secondary-color);
      color: white;
      border: none;
      padding: 10px 20px;
      border-radius: 25px;
      font-weight: bold;
      cursor: pointer;
      transition: all var(--transition-speed);
    }

    .btn-reserve:hover {
      background: var(--primary-color);
      transform: translateY(-2px);
    }

    .back-to-home {
      margin-top: 50px;
      text-align: center;
    }

    .btn-back {
      color: var(--primary-color);
      text-decoration: none;
      font-weight: bold;
      font-size: 1.1em;
      transition: all var(--transition-speed);
    }

    .btn-back:hover {
      color: var(--secondary-color);
    }

    @media (max-width: 768px) {
      .region-image {
        height: 300px;
      }

      .region-description {
        font-size: 1em;
      }

      .activites-grid {
        grid-template-columns: 1fr;
      }
    }
  `]
})
export class RegionDetailComponent {
  region?: Region;
  activites: Activite[] = [];

  constructor(private route: ActivatedRoute) {
    const regionId = Number(this.route.snapshot.paramMap.get('id'));
    this.region = REGIONS.find(r => r.id === regionId);
    this.activites = ACTIVITES.filter(a => a.regionId === regionId);
  }
}