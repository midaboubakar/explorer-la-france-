import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { trigger, state, style, transition, animate } from '@angular/animations';
import { Region } from '../../models/region.model';
import { REGIONS } from '../../data/regions';

@Component({
  selector: 'app-region-list',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  template: `
    <div class="container">
      <header class="hero">
        <h1>Découvrez les Merveilles de la France</h1>
        <p class="subtitle">Explorez nos régions et leurs trésors cachés</p>
      </header>
      
      <div class="search-container">
        <div class="search-box">
          <input 
            type="text" 
            [(ngModel)]="searchTerm" 
            (ngModelChange)="search()"
            placeholder="Rechercher une région ou une activité..."
            class="search-input"
          >
          <span class="search-icon">🔍</span>
        </div>
      </div>

      <div class="regions-grid">
        <div *ngFor="let region of filteredRegions" 
             class="region-card" 
             [routerLink]="['/region', region.id]"
             [@fadeInOut]>
          <div class="card-image-container">
            <img [src]="region.image" [alt]="region.nom">
            <div class="card-overlay">
              <span class="explore-text">Explorer</span>
            </div>
          </div>
          <div class="card-content">
            <h2>{{ region.nom }}</h2>
            <p>{{ region.description }}</p>
            <button class="btn-discover">Découvrir →</button>
          </div>
        </div>
      </div>
    </div>
  `,
  animations: [
    trigger('fadeInOut', [
      state('void', style({ opacity: 0, transform: 'translateY(20px)' })),
      transition('void <=> *', animate('400ms cubic-bezier(0.4, 0, 0.2, 1)'))
    ])
  ],
  styles: [`
    .container {
      max-width: 1400px;
      margin: 0 auto;
      padding: 20px;
    }

    .hero {
      text-align: center;
      margin-bottom: 50px;
      padding: 60px 20px;
      background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
      color: white;
      border-radius: 15px;
    }

    .hero h1 {
      color: white;
      margin-bottom: 15px;
    }

    .hero h1::after {
      background-color: white;
    }

    .subtitle {
      font-size: 1.2em;
      opacity: 0.9;
    }

    .search-container {
      margin: 30px 0;
      text-align: center;
    }

    .search-box {
      position: relative;
      max-width: 600px;
      margin: 0 auto;
    }

    .search-input {
      width: 100%;
      padding: 15px 25px;
      border: 2px solid #ddd;
      border-radius: 30px;
      font-size: 1.1em;
      transition: all var(--transition-speed);
      padding-right: 50px;
    }

    .search-input:focus {
      outline: none;
      border-color: var(--secondary-color);
      box-shadow: 0 0 10px rgba(52, 152, 219, 0.2);
    }

    .search-icon {
      position: absolute;
      right: 20px;
      top: 50%;
      transform: translateY(-50%);
      font-size: 1.2em;
      opacity: 0.5;
    }

    .regions-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
      gap: 30px;
      margin-top: 30px;
    }

    .region-card {
      border-radius: 15px;
      overflow: hidden;
      background: white;
      box-shadow: var(--card-shadow);
      cursor: pointer;
      transition: all var(--transition-speed);
    }

    .region-card:hover {
      transform: translateY(-10px);
      box-shadow: 0 8px 15px rgba(0, 0, 0, 0.2);
    }

    .card-image-container {
      position: relative;
      overflow: hidden;
      height: 250px;
    }

    .card-image-container img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      transition: transform 0.5s;
    }

    .region-card:hover .card-image-container img {
      transform: scale(1.1);
    }

    .card-overlay {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0, 0, 0, 0.3);
      display: flex;
      align-items: center;
      justify-content: center;
      opacity: 0;
      transition: opacity var(--transition-speed);
    }

    .region-card:hover .card-overlay {
      opacity: 1;
    }

    .explore-text {
      color: white;
      font-size: 1.5em;
      font-weight: bold;
      text-transform: uppercase;
      letter-spacing: 2px;
    }

    .card-content {
      padding: 20px;
    }

    .card-content h2 {
      font-size: 1.5em;
      margin-bottom: 10px;
      color: var(--primary-color);
    }

    .card-content p {
      color: #666;
      margin-bottom: 15px;
    }

    .btn-discover {
      background: none;
      border: none;
      color: var(--secondary-color);
      font-weight: bold;
      cursor: pointer;
      padding: 0;
      font-size: 1.1em;
      transition: all var(--transition-speed);
    }

    .btn-discover:hover {
      color: var(--primary-color);
      transform: translateX(5px);
    }

    @media (max-width: 768px) {
      .hero {
        padding: 40px 20px;
      }

      .regions-grid {
        grid-template-columns: 1fr;
      }

      .card-image-container {
        height: 200px;
      }
    }
  `]
})
export class RegionListComponent {
  regions: Region[] = REGIONS;
  filteredRegions: Region[] = this.regions;
  searchTerm: string = '';

  search() {
    if (!this.searchTerm.trim()) {
      this.filteredRegions = this.regions;
      return;
    }
    
    const searchTermLower = this.searchTerm.toLowerCase();
    this.filteredRegions = this.regions.filter(region => 
      region.nom.toLowerCase().includes(searchTermLower) ||
      region.description.toLowerCase().includes(searchTermLower)
    );
  }
}