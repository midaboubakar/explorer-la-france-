import { Region, Activite } from '../models/region.model';

export const REGIONS: Region[] = [
  {
    id: 1,
    nom: 'Île-de-France',
    description: 'La région capitale, connue pour Paris et ses monuments emblématiques.',
    image: 'https://images.pexels.com/photos/739407/pexels-photo-739407.jpeg'
  },
  {
    id: 2,
    nom: 'Provence-Alpes-Côte d\'Azur',
    description: 'Une région ensoleillée avec ses lavandes et ses plages méditerranéennes.',
    image: 'https://images.pexels.com/photos/3009835/pexels-photo-3009835.jpeg'
  },
  {
    id: 3,
    nom: 'Bretagne',
    description: 'Région côtière connue pour ses traditions et ses paysages maritimes.',
    image: 'https://images.pexels.com/photos/975422/pexels-photo-975422.jpeg'
  },
  {
    id: 4,
    nom: 'Nouvelle-Aquitaine',
    description: 'Plus grande région de France, réputée pour ses vignobles et ses plages.',
    image: 'https://images.pexels.com/photos/2570063/pexels-photo-2570063.jpeg'
  },
  {
    id: 5,
    nom: 'Occitanie',
    description: 'Entre Méditerranée et Pyrénées, riche en sites historiques.',
    image: 'https://images.pexels.com/photos/5759227/pexels-photo-5759227.jpeg'
  },
  {
    id: 6,
    nom: 'Auvergne-Rhône-Alpes',
    description: 'Région montagneuse offrant des paysages spectaculaires.',
    image: 'https://images.pexels.com/photos/1054218/pexels-photo-1054218.jpeg'
  },
  {
    id: 7,
    nom: 'Grand Est',
    description: 'Région frontalière connue pour ses vins et son patrimoine.',
    image: 'https://images.pexels.com/photos/5793977/pexels-photo-5793977.jpeg'
  },
  {
    id: 8,
    nom: 'Hauts-de-France',
    description: 'Terre d\'histoire et de traditions, riche en beffrois.',
    image: 'https://images.pexels.com/photos/5086489/pexels-photo-5086489.jpeg'
  },
  {
    id: 9,
    nom: 'Normandie',
    description: 'Région historique aux falaises impressionnantes.',
    image: 'https://images.pexels.com/photos/2105937/pexels-photo-2105937.jpeg'
  },
  {
    id: 10,
    nom: 'Pays de la Loire',
    description: 'Entre châteaux de la Loire et côte atlantique.',
    image: 'https://images.pexels.com/photos/5759789/pexels-photo-5759789.jpeg'
  },
  {
    id: 11,
    nom: 'Bourgogne-Franche-Comté',
    description: 'Terre de vins et de gastronomie.',
    image: 'https://images.pexels.com/photos/5758011/pexels-photo-5758011.jpeg'
  },
  {
    id: 12,
    nom: 'Centre-Val de Loire',
    description: 'Le jardin de la France et ses châteaux royaux.',
    image: 'https://images.pexels.com/photos/5759573/pexels-photo-5759573.jpeg'
  },
  {
    id: 13,
    nom: 'Corse',
    description: 'Île de beauté aux paysages sauvages.',
    image: 'https://images.pexels.com/photos/4319752/pexels-photo-4319752.jpeg'
  }
];

export const ACTIVITES: Activite[] = [
  {
    id: 1,
    regionId: 1,
    nom: 'Tour Eiffel',
    description: 'Visitez le monument le plus emblématique de Paris',
    lieu: 'Paris',
    image: 'https://images.pexels.com/photos/699466/pexels-photo-699466.jpeg'
  },
  {
    id: 2,
    regionId: 1,
    nom: 'Château de Versailles',
    description: 'Découvrez le faste de la cour des rois de France',
    lieu: 'Versailles',
    image: 'https://images.pexels.com/photos/1125212/pexels-photo-1125212.jpeg'
  },
  {
    id: 3,
    regionId: 2,
    nom: 'Champs de Lavande',
    description: 'Découvrez les magnifiques champs de lavande en Provence',
    lieu: 'Valensole',
    image: 'https://images.pexels.com/photos/2014168/pexels-photo-2014168.jpeg'
  },
  {
    id: 4,
    regionId: 2,
    nom: 'Calanques de Marseille',
    description: 'Randonnée et baignade dans les calanques',
    lieu: 'Marseille',
    image: 'https://images.pexels.com/photos/4319752/pexels-photo-4319752.jpeg'
  },
  {
    id: 5,
    regionId: 3,
    nom: 'Saint-Malo',
    description: 'Explorez la ville fortifiée et ses remparts',
    lieu: 'Saint-Malo',
    image: 'https://images.pexels.com/photos/7031595/pexels-photo-7031595.jpeg'
  },
  {
    id: 6,
    regionId: 3,
    nom: 'Alignements de Carnac',
    description: 'Découvrez les mystérieux menhirs néolithiques',
    lieu: 'Carnac',
    image: 'https://images.pexels.com/photos/6143369/pexels-photo-6143369.jpeg'
  },
  {
    id: 7,
    regionId: 4,
    nom: 'Dune du Pilat',
    description: 'Grimpez la plus haute dune d\'Europe',
    lieu: 'La Teste-de-Buch',
    image: 'https://images.pexels.com/photos/4319752/pexels-photo-4319752.jpeg'
  },
  {
    id: 8,
    regionId: 5,
    nom: 'Cité de Carcassonne',
    description: 'Visitez la plus grande cité médiévale d\'Europe',
    lieu: 'Carcassonne',
    image: 'https://images.pexels.com/photos/5759227/pexels-photo-5759227.jpeg'
  },
  {
    id: 9,
    regionId: 6,
    nom: 'Mont Blanc',
    description: 'Admirez le plus haut sommet des Alpes',
    lieu: 'Chamonix',
    image: 'https://images.pexels.com/photos/1054218/pexels-photo-1054218.jpeg'
  },
  {
    id: 10,
    regionId: 7,
    nom: 'Cathédrale de Strasbourg',
    description: 'Découvrez ce chef-d\'œuvre de l\'art gothique',
    lieu: 'Strasbourg',
    image: 'https://images.pexels.com/photos/5793977/pexels-photo-5793977.jpeg'
  }
];